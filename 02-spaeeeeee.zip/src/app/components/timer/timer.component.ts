import { Component, OnInit } from '@angular/core';
import { CountdownService } from 'src/app/servicios/countdown.service';

@Component({
  selector: 'app-timer',
  templateUrl: './timer.component.html',
  styleUrls: ['./timer.component.css']
})
export class TimerComponent implements OnInit {

seconds: number;
minutes: number;
hours: number;
days: number;

  constructor(private countdownservice: CountdownService) { }

  ngOnInit() {

this.regresivo();
}

regresivo() {
  this.countdownservice.stop();
  this.countdownservice.on('tick', event => {
    this.seconds = event.seconds;
    this.minutes = event.minutes;
    this.hours = event.hours;
    this.days = event.days;
});

const date = new Date(1605639459);

this.countdownservice.start(date);
}

}










