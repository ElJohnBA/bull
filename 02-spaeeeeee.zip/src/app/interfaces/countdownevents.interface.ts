import {TickEvent} from 'src/app/interfaces/tickevent.interface';

export interface CountdownEvents {
    tick(values: TickEvent): void;
    expired(): void;
    stop(): void;
  }
