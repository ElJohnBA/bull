export interface TickEvent {
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
  };
