package com.restbull.rest.controller;

import java.net.URI;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.restbull.rest.model.Server;
import com.restbull.errors.ServerNotFoundException;
import com.restbull.rest.interfaces.IServerService;
import com.restbull.rest.interfaces.ServerRepository;
import com.restbull.services.ServerService;

@RestController
public class ServerController {
	
	@Autowired
	private IServerService serverservice; 
	
    @GetMapping("/servers/get/{id}")
    public Server getServer(@PathVariable Long id){
        return serverservice.findOne(id);
        		
    }

    @PostMapping("/servers/post")
    public Server addServer(@Valid @RequestBody Server server) {
        return serverservice.save(server);
    }

    @PostMapping("/servers/post/{id}")
    public void updateServer(@Valid @PathVariable Long id , @RequestBody Server servidor) {
        serverservice.updateServer(id, servidor);
    }
    
    @PutMapping("/servers/put/{id}")
    public void updateServerAll(@Valid @PathVariable Long id , @RequestBody Server servidor) {
        serverservice.updateServerAll(id, servidor);
    }

    @DeleteMapping("/servers/delete/{id}")
    public void deleteServer(@PathVariable Long id) {
        serverservice.delete(id);
    }
    
    
    
  
    
    
    
    

}