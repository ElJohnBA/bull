package com.restbull.rest.model;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import java.io.Serializable;

@Entity
@Table(name = "serverstatus")
public class Server implements Serializable {
	   
		@Id
        @GeneratedValue(strategy = GenerationType.AUTO)
        private long id;
		
		@NotNull
		@NotEmpty(message = "ingrese ip")
		@Column(name = "ip", nullable = false)
	    private String ip;
		
		@NotNull
		@NotEmpty(message = "ingrese status")
	    @Column(name = "status", nullable = false)
	    private String status;
		
		@Version
	    private Integer version;
		// SIN METODO SET, YA QUE SE INCREMENTA SOLO
		public Integer getVersion() {
			return version;
		}
	    
	    public Server () {}
	    
	    public Server (long id, String ip, String status) {
	    	this.id = id;
	    	this.ip = ip;
	    	this.status = status;
	    }


	    public String getIp() {
			return ip;
		}

		public void setIp(String ip) {
			this.ip = ip;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}
		
		public long getId() {
			return id;
		}

		public void setId(long id) {
			this.id = id;
		}

        @Override
	    public String toString() {
	        return "Server [ip=" + ip + ", status=" + status  + "]";
	    }

}
