package com.restbull.rest.interfaces;

import javax.persistence.LockModeType;

import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.restbull.rest.model.Server;

@Repository
public interface ServerRepository extends CrudRepository<Server, Long> {
	
	
	
}