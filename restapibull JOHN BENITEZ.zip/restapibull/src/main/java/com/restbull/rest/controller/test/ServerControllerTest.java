package com.restbull.rest.controller.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.restbull.rest.model.Server;
import com.restbull.services.ServerService;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest
public class ServerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ServerService serverService;

    @Test
    public void findAll() throws Exception {
        Server server = new Server();
        server.setId(1L);
        server.setIp("127.0.0.1");
        server.setStatus("STOPPED");

        given(serverService.findOne(1L)).willReturn(server);

        this.mockMvc.perform(get("/servers/get/1"))
                .andExpect(status().isOk())
                .andExpect(content().json("{'id': 1,'ip': '127.0.0.1','status': 'STOPPED'}"));
    }
}