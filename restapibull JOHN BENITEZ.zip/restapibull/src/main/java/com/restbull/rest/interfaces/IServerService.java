package com.restbull.rest.interfaces;

import java.util.List;

import com.restbull.rest.model.Server;;

public interface IServerService {
	
	public List<Server> findAll();
	
	public Server save(Server server);
	
	public Server findOne(Long id);
	
	public void delete(Long id);

	public void updateServer(Long id, Server servidor);
	
	public void updateServerAll(Long id, Server servidor);

}
