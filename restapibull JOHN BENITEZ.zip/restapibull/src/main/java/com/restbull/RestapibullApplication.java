package com.restbull;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
 
@SpringBootApplication
public class RestapibullApplication {
 
    public static void main(String[] args) {
        SpringApplication.run(RestapibullApplication.class, args);
    }
}
