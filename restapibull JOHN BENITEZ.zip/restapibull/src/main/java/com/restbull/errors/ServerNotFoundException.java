package com.restbull.errors;

public class ServerNotFoundException extends RuntimeException {

    public ServerNotFoundException(Long id) {
        super("servidor no encontrado : " + id);
    }

}