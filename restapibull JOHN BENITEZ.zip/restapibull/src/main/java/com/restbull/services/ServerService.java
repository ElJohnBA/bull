package com.restbull.services;

import com.restbull.rest.model.Server;
import com.restbull.errors.ServerNotFoundException;
import com.restbull.rest.interfaces.IServerService;
import com.restbull.rest.interfaces.ServerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServerService implements IServerService{

    @Autowired
    private ServerRepository serverrepository;

    public List<Server> findAll() {
		return (List<Server>) serverrepository.findAll();

    }

    @Override
    public Server findOne(Long id) {
		return serverrepository.findById(id).orElseGet(() -> {
            throw new ServerNotFoundException(id);
        });
    }

    public Server save(Server servidor) {
    	return serverrepository.save(servidor);

    }

    public void updateServer(Long id, Server servidor) {
    	serverrepository.findById(id).map(
    			temp -> {
    	            temp.setIp(servidor.getIp());
    	            temp.setStatus(servidor.getStatus());
    	            return serverrepository.save(temp);
    	        });
    	}
    
    public void updateServerAll(Long id, Server servidor) {
    	Server toDelete = new Server();
    	toDelete = serverrepository.findById(id).orElseGet(() -> {
            throw new ServerNotFoundException(id);
        });
    	
    	serverrepository.deleteById(toDelete.getId());
    	serverrepository.save(servidor);
    	
    }

    @Override
    public void delete(Long id) {
    	Server toDelete = new Server();
    	toDelete = serverrepository.findById(id).orElseGet(() -> {
            throw new ServerNotFoundException(id);
        });
    	
    	serverrepository.deleteById(toDelete.getId());
    }

	



	

	
	

}