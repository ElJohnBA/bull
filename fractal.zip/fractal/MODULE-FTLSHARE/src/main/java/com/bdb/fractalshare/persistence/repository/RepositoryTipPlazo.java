package com.bdb.fractalshare.persistence.repository;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bdb.fractalshare.persistence.entity.TipplazoParDownEntity;

public interface RepositoryTipPlazo extends JpaRepository<TipplazoParDownEntity, Serializable> {

	//public List<TipplazoParDownEntity> findByHomoDcvbta();
}
