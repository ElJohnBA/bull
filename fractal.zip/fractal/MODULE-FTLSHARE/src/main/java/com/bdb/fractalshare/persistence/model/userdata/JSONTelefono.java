package com.bdb.fractalshare.persistence.model.userdata;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class JSONTelefono {

    /**
     * Teléfono del cliente (deben ser solo números).
     */
    @NotNull
    @Pattern(regexp = "^([0-9]{7,10})$", message = "Ingrese un número de teléfono válido.")
    private String numero;

    @Pattern(regexp = "^([0-9]{1,5})$", message = "Ingrese una extensión válida.")
    private String extension;
    
    /**
     * TODO: (Carolina Medina): Validar con el desarrollo del archivo p.
     */
    private String numero_fax;
}
