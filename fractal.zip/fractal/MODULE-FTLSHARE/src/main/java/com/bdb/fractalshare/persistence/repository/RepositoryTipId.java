package com.bdb.fractalshare.persistence.repository;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bdb.fractalshare.persistence.entity.TipidParDownEntity;

public interface RepositoryTipId extends JpaRepository<TipidParDownEntity, Serializable> {

	public List<TipidParDownEntity> findByHomoDcvbtaNot(String codigo);
	
}
