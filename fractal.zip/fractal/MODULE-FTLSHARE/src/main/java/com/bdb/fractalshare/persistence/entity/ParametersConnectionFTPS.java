package com.bdb.fractalshare.persistence.entity;

public class ParametersConnectionFTPS {

	private String username;

	private String password;
	
	private String hostname;
	
	private Integer puerto;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public Integer getPuerto() {
		return puerto;
	}

	public void setPuerto(Integer puerto) {
		this.puerto = puerto;
	}

	public ParametersConnectionFTPS(String username, String password, String hostname, Integer puerto) {
		super();
		this.username = username;
		this.password = password;
		this.hostname = hostname;
		this.puerto = puerto;
	}

	public ParametersConnectionFTPS() {
		super();
		// TODO Auto-generated constructor stub
	}
}
