package com.bdb.fractalshare.persistence.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bdb.fractalshare.persistence.entity.HisTranpgEntity;

public interface RepositoryTransaccionesPago extends JpaRepository<HisTranpgEntity, Serializable> {

}
