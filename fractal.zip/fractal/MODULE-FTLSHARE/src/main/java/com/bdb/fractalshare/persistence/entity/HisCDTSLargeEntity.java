package com.bdb.fractalshare.persistence.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "OPL_HIS_CDTS_LARGE_TBL")
public class HisCDTSLargeEntity implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "NUM_CDT")
    private String numCdT;

    @Column(name = "FECHA")
    private Date fecha;

    @Column(name = "USUARIO")
    private String usuario;

    @Column(name = "CANAL")
    private String canal;

    @Column(name = "COD_CUT")
    private String codCut;

    @Column(name = "COD_TRN")
    private String codTrn;

    @Column(name = "COD_PROD")
    private String codProd;

    @Column(name = "MERCADO")
    private String mercado;

    @Column(name = "UNID_NEGOCIO")
    private String unidNegocio;

    @Column(name = "UNID_CEO")
    private String unidCeo;

    @Column(name = "FORMA_PAGO")
    private String formaPago;

    @Column(name = "OPL_DEPOSITANTE_TBL_TIP_DEPOSITANTE")
    private Integer oplDepositanteTblTipDepositante;

    @Column(name = "OPL_OFICINA_TBL_NRO_OFICINA")
    private Integer oplOficinaTblNroOficina;

    @Column(name = "TIP_PLAZO")
    private String tipPlazo;

    @Column(name = "PLAZO")
    private Integer plazo;

    @Column(name = "FECHA_EMI")
    private Date fechaEmi;

    @Column(name = "FECHA_VEN")
    private Date fechaVen;

    @Column(name = "BASE")
    private String base;

    @Column(name = "MODALIDAD")
    private String modalidad;

    @Column(name = "OPL_TIPTASA_TBL_TIP_TASA")
    private Integer oplTiptasaTblTipTasa;

    @Column(name = "OPL_TIPPERIOD_TBL_TIP_PERIODICIDAD")
    private Integer oplTipperiodTblTipPeriodicidad;

    @Column(name = "SIGNO_SPREAD")
    private String signoSpread;

    @Column(name = "SPREAD")
    private BigDecimal spread;

    @Column(name = "TASA_EFE")
    private BigDecimal tasEfe;

    @Column(name = "TASA_NOM")
    private BigDecimal tasNom;

    @Column(name = "MONEDA")
    private BigDecimal moneda;

    @Column(name = "UNID_UVR")
    private String unidUvr;

    @Column(name = "CANT_UNID")
    private BigDecimal cantUnid;

    @Column(name = "VALOR")
    private BigDecimal valor;

    @Column(name = "TIP_TITULARIDAD")
    private String tipTitularidad;

    @Column(name = "OPL_ESTADOS_TBL_TIP_ESTADO")
    private String oplEstadosTblTipEstado;

    @OneToMany(targetEntity = HisTranpgEntity.class,
            mappedBy = "hisCDTSLargeEntity",
            cascade = CascadeType.ALL,
            fetch = FetchType.LAZY)
    private Set<HisTranpgEntity> transacciones;
}
