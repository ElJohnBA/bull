package com.bdb.fractalshare.controller.service.interfaces;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.List;

import org.apache.commons.net.ftp.FTPFile;

import com.bdb.fractalshare.controller.service.errors.ErrorFtps;
import com.bdb.fractalshare.persistence.entity.ParametersConnectionFTPS;

public interface FTPService {

	/*
	 * ESTA INTERFACE PERMITE CONSTRUIR LOS METODOS QUE SERAN PROPIOS DEL SERVICEIMPLEMENTS (FTPSSERVICEIMPL) , ESTA CLASE 
	 * SIEMPRE DEBERA SER LLAMADA PARA TRABAJAR CON LOS SERVICESIMPLEMENTS , ESTO SE REALIZA PARA MANTENER UNA ORGANIZACION , 
	 * PODER REUTILIZAR CODIGO Y MANTENER INTEGRIDAD ENTRE LAS DIFERENTES CAPAS. 
	 */
	
	void connectToFTP(String host, int port, String user, String pass) throws ErrorFtps;
    void uploadFileToFTP(File file, String ftpHostDir , String serverFilename) throws ErrorFtps;
    void downloadFileFromFTP(String ftpRelativePath, String copytoPath) throws ErrorFtps;
    void disconnectFTP() throws ErrorFtps;
    ByteArrayOutputStream archivoResource(String ftpRelativePath) throws ErrorFtps;
    void makeDirectoryDay() throws ErrorFtps;
    void makeSubDirectorys() throws ErrorFtps;
    void updateFile(ByteArrayInputStream linea) throws ErrorFtps;
    void makeFile(ByteArrayOutputStream archivo, String ftpHostDir, String serverFilename) throws ErrorFtps;
    String listFile(String inicioArchivo) throws ErrorFtps;
    String obtenerFechaActual();
    FTPFile[] listFileParameters(String inicioArchivo) throws ErrorFtps;
    List<String> getNameParameters() throws ErrorFtps;
    ParametersConnectionFTPS parametersConnection();
}
