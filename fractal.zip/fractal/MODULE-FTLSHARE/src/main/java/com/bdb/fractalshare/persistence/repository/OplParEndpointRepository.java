package com.bdb.fractalshare.persistence.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bdb.fractalshare.persistence.entity.OplParEndpoint;

public interface OplParEndpointRepository extends JpaRepository<OplParEndpoint, Integer>, OplParEndpointRepositoryCustom {

}
