package com.bdb.fractalshare.controller.service.implement;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bdb.fractalshare.controller.service.interfaces.SharedService;
import com.bdb.fractalshare.persistence.entity.MaeDCVTempDownEntity;
import com.bdb.fractalshare.persistence.repository.RepositoryCDTsDesmaterializado;

@Service
public class SharedServiceImpl implements SharedService {
	
	JSONObject json;
	
	@Autowired
	private RepositoryCDTsDesmaterializado repoOracle;

	public JSONObject encabezado(Map<String, String> parametros) {
		this.json = new JSONObject();
		this.json.put("app", parametros.get("app"));
		parametros.remove("app");
		this.json.put("nameServiceResponse", parametros.get("nameServiceResponse"));
		parametros.remove("nameServiceResponse");
		this.json.put("date", formatoFecha());
		System.out.println("paso1");		
		JSONObject parametrosRequest = new JSONObject();
		for(Map.Entry<String, String> entry : parametros.entrySet()) {
			System.out.println("entro");
			parametrosRequest.put( entry.getKey() , entry.getValue() == null ? "null" : entry.getValue() );
		}
		System.out.println("paso2");
		/*parametrosRequest.put("identificación", pruebas.getParametros().getIdentificacion() == null ? "null" : pruebas.getParametros().getIdentificacion());
		parametrosRequest.put("tipoDocumento", pruebas.getParametros().getTipoDocumento() == null ? "null" : pruebas.getParametros().getTipoDocumento());*/
		this.json.put("parametrosRequest", parametrosRequest);
		return json;
	}
	
	public String formatoFecha() {
		Date fechaActual = new Date();
    	String formato = "dd/MM/yy HH:mm:ss";
    	SimpleDateFormat simpleFormato = new SimpleDateFormat(formato);
    	String obtenerFecha = simpleFormato.format(fechaActual);
    	System.out.println("LA FECHA ES: " + obtenerFecha);
    	return obtenerFecha;
	}
	
	public Map<String, String> parametros(Map<String, String> request , String nombreService){
		Map<String, String> parametros = new HashMap<String, String>();
		parametros.put("app", "OPALOBDB");
		parametros.put("nameServiceResponse", nombreService);
		for(Map.Entry<String, String> conocer : request.entrySet()) {
			parametros.put(conocer.getKey(), conocer.getValue());
		}
		return parametros;
	}
	
	public String campoEntrada(String campo) {
		campo = campo == null ? "" : campo;
		return campo;
	}

}