package com.bdb.fractalshare.persistence.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="CONDICIONES_CDT")
public class CondicionesCDTEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Column(name="NUM_CDT")
	private String numCdT;
	
	@Column(name="DEPOSITANTE")
	private String depositante;
	
	@Id
	@Column(name="CTA_INVER")
	private String ctaInver;
	
	@Column(name="FORMA_PG")
	private String formaPg;
	
	@Column(name="PLAZO_DIAS")
	private Integer plazoDias;
	
	@Column(name="TIP_PLAZO")
	private String tipPlazo;
	
	@Column(name="FECHA_EMI")
	private String fechaEmi;
	
	@Column(name="FECHA_VEN")
	private String fechaVen;
	
	@Column(name="BASE")
	private String base;
	
	@Column(name="INDICADOR")
	private String indicador;
	
	@Column(name="SPREAD")
	private BigDecimal spread;
	
	@Column(name="PERIODICIDAD_PG")
	private String periodicidadPg;
	
	@Column(name="MODALIDAD_PG")
	private String modalidadPg;
	
	@Column(name="TAS_EFEC")
	private BigDecimal tasEfec;
	
	@Column(name="TAS_NOMINAL")
	private BigDecimal tasNominal;
	
	@Column(name="MODALIDAD")
	private String modalidad;
	
	@Column(name="MONEDA")
	private String moneda;
	
	@Column(name="VLR_UVR")
	private BigDecimal vlrUvr;
	
	@Column(name="VLR_PESOS")
	private BigDecimal vlrPesos;
	
	@Column(name="IND_MANCOMUNADOS")
	private String indMancomunados;
	
	@Column(name="TITULARIDAD")
	private String titularidad;
	
	@Column(name="ID_CLIENTE1")
	private String idCliente1;
	
	@Column(name="ID_CLIENTE2")
	private String idCliente2;
	
	@Column(name="ID_CLIENTE3")
	private String idCliente3;
	
	@Column(name="ID_CLIENTE4")
	private String idCliente4;
	
	@Column(name="MERCADO")
	private String mercado;
	
	@Column(name="COD_SUCURSAL_ADMIN")
	private String codSucursalAdmin;
	
	@Column(name="USR_NT")
	private String usrNt;

}
