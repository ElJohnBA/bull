package com.bdb.fractalshare.persistence.entity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="TRANSACCIONES_PAGO_CDTS_DESMATERIALIZADO")
public class TransaccionesPagosCDTDesEntity {

	@Id
	@Column(name="NUM_CTA")
	private String numCta;
	
	@Column(name="ITEM")
	private Integer item;
	
	@Column(name="PROCESO")
	private String proceso;
	
	@Column(name="TIPO_TRANSACCION")
	private Integer tipoTransaccion;
	
	@Column(name="TRANSACCION")
	private String transaccion;
	
	@Column(name="VALORES")
	private BigDecimal valores;
	
	@Column(name="UNIDAD_NEGOCIO")
	private String unidadNegocio;
	
	
	
	@Column(name="NOM_TIT")
	private String nomTit;
	
	@Column(name="OBSERVACIONES")
	private String observaciones;
		
}
