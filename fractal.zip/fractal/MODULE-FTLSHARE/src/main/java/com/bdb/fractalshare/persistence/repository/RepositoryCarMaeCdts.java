package com.bdb.fractalshare.persistence.repository;

import java.io.Serializable;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.bdb.fractalshare.persistence.entity.MaeCDTSCarEntity;

public interface RepositoryCarMaeCdts extends JpaRepository<MaeCDTSCarEntity, Serializable> {
		
	@Transactional
	@Modifying
	@Query("update MaeCDTSCarEntity c set tipId = (SELECT codId FROM TipidParDownEntity h WHERE h.homoDcvbta = :tipoDocumento ) " + 
			"WHERE c.tipId = :tipoDocumento  ")
	public void homologarCodId(String tipoDocumento);
	
	@Transactional
	@Modifying
	@Query("update MaeCDTSCarEntity c set tipPlazo = (SELECT tipPlazo FROM TipplazoParDownEntity h WHERE h.homoDcvbta = :tipoPlazo ) " + 
			"WHERE c.tipPlazo = :tipoPlazo  ")
	public void homologarTipPlazo(String tipoPlazo);
	
	@Transactional
	@Modifying
	@Query("update MaeCDTSCarEntity c set tipBase = (SELECT tipBase FROM TipbaseParDownEntity h WHERE h.homoDcvbta = :tipoBase ) " + 
			"WHERE c.tipBase = :tipoBase  ")
	public void homologarTipBase(String tipoBase);
	
	@Transactional
	@Modifying
	@Query("update MaeCDTSCarEntity c set tipPeriod = (SELECT tipPeriodicidad FROM TipPeriodParDownEntity h WHERE h.homoDcvbta = :tipoPeriodicidad ) " + 
			"WHERE c.tipPeriod = :tipoPeriodicidad  ")
	public void homologarTipPeriodicidad(String tipoPeriodicidad);
	
	@Transactional
	@Modifying
	@Query("update MaeCDTSCarEntity c set tipTasa = (SELECT tipTasa FROM TiptasaParDownEntity h WHERE h.homoDcvbta = :tipoTasa ) " + 
			"WHERE c.tipTasa = :tipoTasa  ")
	public void homologarTipTasa(String tipoTasa);
	
	@Transactional
	@Modifying
	@Query("update MaeCDTSCarEntity c set posicion = (SELECT tipPosicion FROM TipposicionParDownEntity h WHERE h.homoDcvbta = :tipoPosicion ) " + 
			"WHERE c.posicion = :tipoPosicion  ")
	public void homologarTipPosicion(String tipoPosicion);
}
