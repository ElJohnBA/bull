package com.bdb.fractalshare.persistence.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bdb.fractalshare.persistence.entity.OplMaeDCVTmpEntity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Repository
public interface RepositoryDCVTmp extends JpaRepository<OplMaeDCVTmpEntity, Serializable> {
    public List<OplMaeDCVTmpEntity> findByOficina(String oficina);

    public List<OplMaeDCVTmpEntity> findByFechaReg(Date fechaReg);
}
