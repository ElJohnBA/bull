package com.bdb.fractalshare.persistence.repository;

import java.util.List;
import java.util.Optional;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bdb.fractalshare.persistence.entity.MaeCDTSCarEntity;

@Repository
@Transactional(readOnly = true)

public class OplMaecdtsCarDownTblRepositoryCustomImpl  implements OplMaecdtsCarDownTblRepositoryCustom{

	@PersistenceContext
    EntityManager entityManager;
	
	Logger logger = LoggerFactory.getLogger(OplMaecdtsCarDownTblRepositoryCustomImpl.class);

	
	@Override
	public List<List<String>> findDif() {
		
		Query query = entityManager.createNativeQuery("SELECT (SELECT HOMO_CRM FROM OPL_PAR_TIPID_DOWN_TBL WHERE COD_ID = TIP_ID ) as TIP_ID,ID_TIT FROM OPL_CAR_MAECDTS_DOWN_TBL car WHERE NOT EXISTS (SELECT ID_TIT FROM OPL_TMP_MAEDCV_DOWN_TBL WHERE ID_TIT = car.ID_TIT)");
		
		 try {
			 List<List<String>> listCar = query.getResultList();
	        	if(!listCar.isEmpty()) {
	        		return listCar;
	        	}
	        	entityManager.flush();
	        	entityManager.close();
	        	
	        }
	        catch (Exception e) {
	        	logger.error("ERROR IN OplMaecdtsCarDownTblRepositoryCustomImpl: "+e.getMessage());
	        }finally {
	        	entityManager.close();
	        }
		return null;
	}

}
