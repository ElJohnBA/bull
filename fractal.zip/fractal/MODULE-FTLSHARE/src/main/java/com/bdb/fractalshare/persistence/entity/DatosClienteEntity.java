package com.bdb.fractalshare.persistence.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="OPL_HIS_CLIENTES_LARGE_TBL")
public class DatosClienteEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="NUM_TIT")
	private String numTit;
	
	@Column(name="OPL_TIPID_PAR")
	private Integer OPL_;
			
	@Column(name="NOM_TIT")
	private String nomTit;
	
	@Column(name="DIR")
	private String dir;
	
	@Column(name="TEL")
	private String tel;
	
	@Column(name="EXTENSION")
	private String extension;
	
	@Column(name="CLA_TIT")
	private String claTit;
	
	@Column(name="CALIDAD_CONTRIBUYENTE")
	private String calidadContribuyente;
	
	@Column(name="DECLARA_RENTA")
	private String declaraRenta;
	
	@Column(name="CORREO")
	private String correo;
	
	@Column(name="PAIS_NACIMIENTO")
	private String paisNacimiento;
	
	@Column(name="FECHA_NACIMIENTO")
	private String fechaNacimiento;
	
	@Column(name="COD_CEO")
	private String codCeo;
	
	@Column(name="COD_UNIDAD_NEGOCIO")
	private String codUnidadNegocio;
	
	@Column(name="SEGMENTO_COMERCIAL")
	private String segmentoComercial;
	
	@Column(name="COD_CIIU")
	private String codCiuu;
	
	@Column(name="COD_CLASE_ENTIDAD")
	private String codClaseEntidad;
	
	@Column(name="CALIDAD_FISCAL")
	private String calidadFiscal;
	
	@Column(name="COD_PAIS")
	private String codPais;
	
	@Column(name="COD_DEP")
	private Integer codDep;
	
	@Column(name="COD_CIUD")
	private Integer codCiud;
	
	@Column(name="RESIDENCIA")
	private String residencia;
	
	@Column(name="TIP_INVERSIONISTAS")
	private String tipInversionistas;
	
	@Column(name="TIP_ENTIDAD")
	private String tipEntidad;
	
	@Column(name="NUM_FAX")
	private String numFax;
	
	@Column(name="INDICADOR_EDAD")
	private String indicadorEdad;
	
	@Column(name="CLASIFICACION_ECONOMICA")
	private String clasificacionEconomica;
	
	@Column(name="INDICADOR_EXTRANJERO")
	private String indExtr;
	
	@Column(name="COD_CREE")
	private Integer codCree;
	
}
