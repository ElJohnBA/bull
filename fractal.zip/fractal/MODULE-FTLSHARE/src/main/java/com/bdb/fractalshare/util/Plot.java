package com.bdb.fractalshare.util;

import com.bdb.fractalshare.persistence.model.trad.JSONMonetaryField;
import com.bdb.fractalshare.persistence.model.trad.JSONPlotFields;

/**
 * Copyright (c) 2019 Banco de Bogotá. All Rights Reserved.
 * <p>
 * OPALOBDB was developed by Team Deceval BDB
 * <p>
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * proprietary and confidential. For use this code you need to contact to
 * Banco de Bogotá and request exclusive use permission.
 * <p>
 * This file war write by Jose Buelvas <jbuelva@bancodebogota.com.co>.
 */
public class Plot {

    /**
     * Plot generation DECE APDI Apertura de CDT Desmaterializado.
     *
     * @param data JSON Plot fields
     * @return Plot
     */
    public static String deceApdi(JSONPlotFields data) {
        StringBuilder mon = new StringBuilder();

        for (JSONMonetaryField field : data.getCamposMonetarios()) {
            mon.append(String.format(
                    "%1$02d%2$018d",
                    Integer.parseInt(field.getIdentificador()),
                    field.getValor().longValue()
            ));
        }

        data.setTamParteVariable("" + mon.toString().length());
        data.setNumCamposMonetarios("" + data.getCamposMonetarios().size());

        String plot = String.format(
                "%1$04d%2$s%3$s%4$8s%5$04d%6$04d%7$02d%8$016d%9$02d%10$016d%11$04d%12$s%13$s%14$02d%15$04d",
                Integer.parseInt(data.getCodEntidad()),
                data.getAppFuente(),
                data.getCodTrasaccion(),
                data.getFechaContable(),
                Integer.parseInt(data.getOficinaOrigen()),
                Integer.parseInt(data.getOficinaDestino()),
                Integer.parseInt(data.getProducto()),
                Integer.parseInt(data.getNumProducto()),
                Integer.parseInt(data.getTipoNegocio()),
                Integer.parseInt(data.getNumeroNegocio()),
                Integer.parseInt(data.getCxvcvxvx()),
                data.getCodCajero().toUpperCase(),
                data.getFiller().toUpperCase(),
                Integer.parseInt(data.getNumCamposMonetarios()),
                Integer.parseInt(data.getTamParteVariable())
        );

        return plot + mon.toString();
    }
}
