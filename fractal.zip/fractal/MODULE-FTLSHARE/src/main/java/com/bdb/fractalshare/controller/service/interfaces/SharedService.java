package com.bdb.fractalshare.controller.service.interfaces;

import java.util.List;
import java.util.Map;

import org.json.JSONObject;

import com.bdb.fractalshare.persistence.entity.MaeDCVTempDownEntity;

public interface SharedService {

	public JSONObject encabezado(Map<String,String> parametros);
	
	public String formatoFecha();
	
	public Map<String, String> parametros(Map<String, String> request , String nombreServicio);
	
	public String campoEntrada(String campo);
	
}
