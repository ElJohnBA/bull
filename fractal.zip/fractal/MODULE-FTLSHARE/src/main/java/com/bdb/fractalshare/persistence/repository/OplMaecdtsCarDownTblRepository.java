package com.bdb.fractalshare.persistence.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bdb.fractalshare.persistence.entity.MaeCDTSCarEntity;

@Repository
public interface OplMaecdtsCarDownTblRepository extends JpaRepository<MaeCDTSCarEntity, Long>, OplMaecdtsCarDownTblRepositoryCustom {

	

}
