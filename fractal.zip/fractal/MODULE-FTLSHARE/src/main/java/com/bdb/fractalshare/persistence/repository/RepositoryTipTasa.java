package com.bdb.fractalshare.persistence.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bdb.fractalshare.persistence.entity.TiptasaParDownEntity;

public interface RepositoryTipTasa extends JpaRepository<TiptasaParDownEntity, Serializable> {

}
