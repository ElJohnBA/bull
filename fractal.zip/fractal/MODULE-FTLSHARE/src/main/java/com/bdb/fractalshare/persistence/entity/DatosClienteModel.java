package com.bdb.fractalshare.persistence.entity;

import java.util.Date;

import javax.persistence.Column;

public class DatosClienteModel {

	private Integer tipId;
	
	private String numTit;
	
	private String nomTit;
	
	private String dir;
	
	private String tel;
	
	private String extension;
	
	private String claTit;
	
	private String calidadContribuyente;
	
	private String declaraRenta;
	
	private String correo;
	
	private String paisNacimiento;
	
	private String fechaNacimiento;
	
	private String codCeo;
	
	private String codUnidadNegocio;
	
	private String segmentoComercial;
	
	private String codCiuu;
	
	private String codClaseEntidad;
	
	private String calidadFiscal;
	
	private String codPais;
	
	private Integer codDep;
	
	private Integer codCiud;
	
	private String residencia;
	
	private String tipInversionistas;
	
	private String tipEntidad;
	
	private String numFax;
	
	private String indicadorEdad;
	
	private String clasificacionEconomica;
	
	private String indExtr;
	
	private Integer codCree;
	
	
}
