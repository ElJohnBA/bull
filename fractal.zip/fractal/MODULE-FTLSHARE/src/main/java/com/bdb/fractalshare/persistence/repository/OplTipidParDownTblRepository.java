package com.bdb.fractalshare.persistence.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bdb.fractalshare.persistence.entity.TipidParDownEntity;

@Repository
public interface OplTipidParDownTblRepository extends JpaRepository<TipidParDownEntity, Integer> {

}
