package com.bdb.fractalshare.persistence.repository;

import java.util.List;
import java.util.Optional;

import com.bdb.fractalshare.persistence.entity.MaeCDTSCarEntity;

public interface OplMaecdtsCarDownTblRepositoryCustom {
	
	List<List<String>> findDif();


}
