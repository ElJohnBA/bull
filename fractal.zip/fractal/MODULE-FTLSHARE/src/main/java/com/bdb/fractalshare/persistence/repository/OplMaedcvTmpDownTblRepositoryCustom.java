package com.bdb.fractalshare.persistence.repository;

import java.util.List;
import java.util.Optional;

import com.bdb.fractalshare.persistence.entity.MaeDCVTempDownEntity;

public interface OplMaedcvTmpDownTblRepositoryCustom {
	
	List<List<String>> findDif();

}
