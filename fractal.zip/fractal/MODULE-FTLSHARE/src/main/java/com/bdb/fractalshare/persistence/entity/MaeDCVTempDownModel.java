package com.bdb.fractalshare.persistence.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class MaeDCVTempDownModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long item;
	private Date fechaReg;
	private String codIsin;
	private String numCDT;
	private String numFol;
	private String ctaInv;
	private String idTit;
	private String nomTit;
	private String correo;
	private String fechaEmi;
	private String fechaVen;
	private String fechaProPago;
	private BigDecimal spread;
	private BigDecimal tasEfe;
	private BigDecimal tasNom;
	private BigDecimal vlrCDT;
	private String oficina;
	private String tipId;
	private String tipPlazo;
	private String base;
	private String periocidad;
	private String tipTasa;
	private String posicion;
	
	
	private String descBase;
	
	private String descPerodicidad;
	
	private String plazo;
	private String desTasa;
	
	private String estado;
	
	private String fraccionado;
	
	private String nomId;
	private String descPosicion;

	public MaeDCVTempDownModel(Long item, String codIsin, String numCDT, String idTit , String oplTipidParDownTblCodId, String nomId, String nomTit, String ctaInv,
			String plazo, String oplTipplazoParDownTblTipPlazo, String fechaEmi, String fechaVen, BigDecimal vlrCDT, String oplTipbaseParDownTblTipBase , String base, String oplTipperiodParDownTblTipPeriodicidad , String periocidad, 
			BigDecimal spread, BigDecimal tasNom, BigDecimal tasEfe, String oplOficinaParDownTblNroOficina, String oplTipposicionParDownTblTipPosicion , String posicion, String estado,
			String oplTiptasaParDownTblTipTasa, String desTasa , String fechaProPago , String correo , String fraccionado) {
		super();
		this.item = item;
		this.codIsin = codIsin;
		this.numCDT = numCDT;
		this.idTit = idTit;
		this.ctaInv = ctaInv;
		this.tipId = oplTipidParDownTblCodId;
		this.nomId = nomId;
		this.nomTit = nomTit;
		this.fechaEmi = fechaEmi;
		this.fechaVen = fechaVen;
		this.tipPlazo = oplTipplazoParDownTblTipPlazo;
		this.plazo = plazo;
		this.descBase = base;
		this.base = oplTipbaseParDownTblTipBase;
		this.descPerodicidad = periocidad;
		this.periocidad = oplTipperiodParDownTblTipPeriodicidad;
		this.spread = spread;
		this.tasNom = tasNom;
		this.tasEfe = tasEfe;
		this.posicion = oplTipposicionParDownTblTipPosicion;
		this.descPosicion = posicion;
		this.oficina = oplOficinaParDownTblNroOficina;
		this.vlrCDT = vlrCDT;
		this.estado = estado;
		this.tipTasa = oplTiptasaParDownTblTipTasa;
		this.desTasa = desTasa;
		this.correo = correo;
		this.fechaProPago = fechaProPago;
		this.fraccionado = fraccionado;
	}
}
