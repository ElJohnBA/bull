package com.bdb.fractalshare.persistence.repository;

public interface OplParEndpointRepositoryCustom {
	
	String getParametro();

}
