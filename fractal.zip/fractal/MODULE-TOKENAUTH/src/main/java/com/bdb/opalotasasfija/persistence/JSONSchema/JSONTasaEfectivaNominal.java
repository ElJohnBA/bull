package com.bdb.opalotasasfija.persistence.JSONSchema;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class JSONTasaEfectivaNominal {


	@NotNull
	private String canal;
	
	@NotNull
	private ParametrosJSONTasaEfectivaNominal parametros;

	public String getCanal() {
		return canal;
	}

	public void setCanal(String canal) {
		this.canal = canal;
	}

	public ParametrosJSONTasaEfectivaNominal getParametros() {
		return parametros;
	}

	public void setParametros(ParametrosJSONTasaEfectivaNominal parametros) {
		this.parametros = parametros;
	}

	public JSONTasaEfectivaNominal(String canal, ParametrosJSONTasaEfectivaNominal parametros) {
		super();
		this.canal = canal;
		this.parametros = parametros;
	}

	public JSONTasaEfectivaNominal() {
		super();
	}
	
}
