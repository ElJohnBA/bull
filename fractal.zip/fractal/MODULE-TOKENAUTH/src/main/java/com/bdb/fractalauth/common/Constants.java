package com.bdb.fractalauth.common;

public class Constants {
	
private Constants(){}
	
    // ********** BASES  **********
	public static final double BASE_360 = 360F;
	public static final double BASE_365 = 365F;
	public static final double BASE_366 = 366F;
	
    // ********** PERIODO  **********
	public static final double PER_1 = 30F;
	public static final double PER_2 = 60F;
	public static final double PER_3 = 90F;
	public static final double PER_4 = 120F;
	public static final double PER_5 = 150F;
	public static final double PER_6 = 180F;
	public static final double PER_7 = 210F;
	public static final double PER_8 = 240F;
	public static final double PER_10 = 300F;
	public static final double PER_12 = 360F;
	public static final double PER_18 = 540F;
	public static final double PER_24 = 720F;
	public static final double PER_30 = 900F;
	public static final double PER_36 = 1080F;
	public static final double PER_42 = 1260F;
	public static final double PER_48 = 1440F;
	public static final double PER_60 = 1800F;

}
