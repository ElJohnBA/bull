package com.bdb.opalotasasfija.persistence.JSONSchema;

public class ResultJSONCuotas {
	
	private double interesBruto;
    private double retencionIntereses;
    private double interesNeto;
    private double interesBrutoPeriodo;
    private double retencionInteresesPeriodo;
    private double interesNetoPeriodo;
    
	public double getInteresBruto() {
		return interesBruto;
	}
	public void setInteresBruto(double interesBruto) {
		this.interesBruto = interesBruto;
	}
	public double getRetencionIntereses() {
		return retencionIntereses;
	}
	public void setRetencionIntereses(double retencionIntereses) {
		this.retencionIntereses = retencionIntereses;
	}
	public double getInteresNeto() {
		return interesNeto;
	}
	public void setInteresNeto(double interesNeto) {
		this.interesNeto = interesNeto;
	}
	public double getInteresBrutoPeriodo() {
		return interesBrutoPeriodo;
	}
	public void setInteresBrutoPeriodo(double interesBrutoPeriodo) {
		this.interesBrutoPeriodo = interesBrutoPeriodo;
	}
	public double getRetencionInteresesPeriodo() {
		return retencionInteresesPeriodo;
	}
	public void setRetencionInteresesPeriodo(double retencionInteresesPeriodo) {
		this.retencionInteresesPeriodo = retencionInteresesPeriodo;
	}
	public double getInteresNetoPeriodo() {
		return interesNetoPeriodo;
	}
	public void setInteresNetoPeriodo(double interesNetoPeriodo) {
		this.interesNetoPeriodo = interesNetoPeriodo;
	}
	
    
	

}
