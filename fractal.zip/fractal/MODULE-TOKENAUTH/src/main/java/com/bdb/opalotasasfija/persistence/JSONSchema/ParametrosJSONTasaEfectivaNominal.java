package com.bdb.opalotasasfija.persistence.JSONSchema;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;


public class ParametrosJSONTasaEfectivaNominal {
	
	@NotNull
	private String tasaFija;
	
	@NotNull
	private String periodicidad;
	
	@NotNull
	private String base;
	
	@NotNull
	private String diasPlazo;
	
	@NotNull
	private String capital;
	
	@NotNull
	private String retencion;
	
	public String getTasaFija() {
		return tasaFija;
	}
	public void setTasaFija(String tasaFija) {
		this.tasaFija = tasaFija;
	}
	public String getPeriodicidad() {
		return periodicidad;
	}
	public void setPeriodicidad(String periodicidad) {
		this.periodicidad = periodicidad;
	}
	public String getBase() {
		return base;
	}
	public void setBase(String base) {
		this.base = base;
	}
	public String getDiasPlazo() {
		return diasPlazo;
	}
	public void setDiasPlazo(String diasPlazo) {
		this.diasPlazo = diasPlazo;
	}
	public String getCapital() {
		return capital;
	}
	public void setCapital(String capital) {
		this.capital = capital;
	}
	public String getRetencion() {
		return retencion;
	}
	public void setRetencion(String retencion) {
		this.retencion = retencion;
	}
	
	
	public ParametrosJSONTasaEfectivaNominal(String tasaFija, String periodicidad, String base, String diasPlazo,
			String capital, String retencion) {
		super();
		this.tasaFija = tasaFija;
		this.periodicidad = periodicidad;
		this.base = base;
		this.diasPlazo = diasPlazo;
		this.capital = capital;
		this.retencion = retencion;
	}
	
	public ParametrosJSONTasaEfectivaNominal() {
		super();
	}
	
}
