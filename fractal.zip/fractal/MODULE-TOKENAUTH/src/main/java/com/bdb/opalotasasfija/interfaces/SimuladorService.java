package com.bdb.opalotasasfija.interfaces;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseEntity;

import com.bdb.opalotasasfija.persistence.JSONSchema.JSONTasaEfectivaNominal;
import com.bdb.opalotasasfija.persistence.JSONSchema.ResultJSONCuotas;

public interface SimuladorService {

	public ResponseEntity simuladorCuota(JSONTasaEfectivaNominal rq, HttpServletRequest request);
			
}
