package com.bdb.opalotasasfija.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bdb.fractalauth.common.Constants;
import com.bdb.opaloshare.controller.service.interfaces.ErrorsJsonService;
import com.bdb.opaloshare.controller.service.interfaces.SharedService;
import com.bdb.opaloshare.persistence.model.response.RequestResult;
import com.bdb.opaloshare.persistence.model.response.ResultMessage;
import com.bdb.opalotasasfija.interfaces.Calculadora;
import com.bdb.opalotasasfija.interfaces.SimuladorService;
import com.bdb.opalotasasfija.persistence.JSONSchema.JSONTasaEfectivaNominal;
import com.bdb.opalotasasfija.persistence.JSONSchema.ResultJSONCuotas;

@Service
public class SimuladorServiceImpl implements SimuladorService {
	
	@Autowired
	private Calculadora calculadora;
	
		
	
	@Override
	public ResponseEntity simuladorCuota(JSONTasaEfectivaNominal rq, HttpServletRequest request) {
		
		List<Double> interesList = new ArrayList<>();
		JSONObject json = new JSONObject();
		JSONObject cuotas = new JSONObject();
		JSONObject simulacionCuotas1 = new JSONObject();
		JSONObject cuotasPeriodo = new JSONObject();
        Map<String,String> parametros = parseoJson(rq);
        ResultJSONCuotas resultJSONCuotas = new ResultJSONCuotas();
        RequestResult<ResultMessage> simulacionCuotasError;
        RequestResult<ResultJSONCuotas> simulacionCuotas ;
       try {
    	   
   		double tasaFija = Double.valueOf((rq.getParametros().getTasaFija() == null ? null : rq.getParametros().getTasaFija()));
   		String periodicidad = rq.getParametros().getPeriodicidad() == null ? null : rq.getParametros().getPeriodicidad();
		String base = rq.getParametros().getBase() == null ? null : rq.getParametros().getBase();
		double diasPlazo = Double.valueOf((rq.getParametros().getDiasPlazo() == null ? null : rq.getParametros().getDiasPlazo()));
		double capital = Double.valueOf((rq.getParametros().getCapital() == null ? null : rq.getParametros().getCapital()));
		double retencion = Double.valueOf((rq.getParametros().getRetencion() == null ? null : rq.getParametros().getRetencion()));
		
        double baseDias = baseDias(base);
		
        double periodicidadDias = periodicidadDias(periodicidad, baseDias);
		double periodo = baseDias/periodicidadDias; 
		
		double tasaNominal = calculadora.calcularTasaNominal(tasaFija, periodo);
	    
	    interesList = calculadora.calcularInteres(tasaNominal, diasPlazo, baseDias, capital, retencion, periodo);
	    

	    if(interesList.size() == 0) {
	    	
	    	simulacionCuotasError = new RequestResult<>(request, HttpStatus.BAD_REQUEST);
	    	simulacionCuotasError.setResult(new ResultMessage(String.format("Hubo un error al calcular cuotas")));
	    	return ResponseEntity.ok(simulacionCuotasError);

			
		}else {
			
			resultJSONCuotas.setInteresBruto(interesList.get(0));
			resultJSONCuotas.setRetencionIntereses(interesList.get(1));
			resultJSONCuotas.setInteresNeto(interesList.get(2));
			
			resultJSONCuotas.setInteresBrutoPeriodo(interesList.get(3));
			resultJSONCuotas.setRetencionInteresesPeriodo(interesList.get(4));
			resultJSONCuotas.setInteresNetoPeriodo(interesList.get(5));
						
			simulacionCuotas = new RequestResult<>(request, HttpStatus.OK);
	        simulacionCuotas.setResult(resultJSONCuotas);
	        simulacionCuotas.setParameters(parametros);
			
	    }
		
	} catch (Exception e) {
		simulacionCuotasError = new RequestResult<>(request, HttpStatus.INTERNAL_SERVER_ERROR);
		simulacionCuotasError.setResult(new ResultMessage(String.format("Hubo una excepcion", e)));
		return ResponseEntity.ok(simulacionCuotasError);
	}
       return ResponseEntity.ok(simulacionCuotas);
	
}
	
   public double baseDias(String base) {
		
		double baseDias = 0F;
		
		switch(base) {
		  case "1":
			  baseDias = Constants.BASE_365;
		    break;
		  case "2":
			  baseDias = Constants.BASE_360;
		    break;
		  case "3":
			  baseDias = Constants.BASE_366;
			  break;
		}
		return baseDias;
	}
	
	public double periodicidadDias(String periodicidad, double baseDias) {
		
		double periodicidadDias = 0F;
		
		switch(periodicidad) {
		  case "1":
			  periodicidadDias = baseDias;
		    break;
		  case "2":
			  periodicidadDias = Constants.PER_1;
		    break;
		  case "3":
			  periodicidadDias = Constants.PER_2;
		    break;
		  case "4":
			  periodicidadDias = Constants.PER_3;
		    break;
		  case "5": 
			  periodicidadDias = Constants.PER_4;
		    break;
		  case "6": 
			  periodicidadDias = Constants.PER_5;
		    break;
		  case "7": 
			  periodicidadDias = Constants.PER_6;
		    break;
		  case "8": 
			  periodicidadDias = Constants.PER_7;
		    break;
		  case "9": 
			  periodicidadDias = Constants.PER_8;
		    break;
		  case "10": 
			  periodicidadDias = baseDias;
		    break;
		  case "11": 
			  periodicidadDias = Constants.PER_10;
		    break;
		  case "12": 
			  periodicidadDias = Constants.PER_12;
		    break;
		  case "13": 
			  periodicidadDias = Constants.PER_18;
		    break;
		  case "14": 
			  periodicidadDias = Constants.PER_24;
		    break;
		  case "15": 
			  periodicidadDias = Constants.PER_30;
		    break;
		  case "16": 
			  periodicidadDias = Constants.PER_36;
		    break;
		  case "17": 
			  periodicidadDias = Constants.PER_42;
		    break;
		  case "18": 
			  periodicidadDias = Constants.PER_48;
		    break;
		  case "19": 
			  periodicidadDias = Constants.PER_60;
		    break;
		  case "20": 
			  periodicidadDias = baseDias;
		    break;
		}
		return periodicidadDias;
	}
		
	public Map<String, String> parseoJson(JSONTasaEfectivaNominal request) {
		Map<String, String> parametros = new HashMap<>();
		JSONObject json = new JSONObject(request);
		Iterator<?> valor = json.getJSONObject("parametros").keys();
		while(valor.hasNext()) {
			String key = (String) valor.next();
			parametros.put(key, json.getJSONObject("parametros").get(key).toString());
		}
	return parametros;
	}
	
	

}
